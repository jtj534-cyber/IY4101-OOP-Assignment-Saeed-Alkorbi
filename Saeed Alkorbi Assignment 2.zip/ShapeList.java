import java.util.ArrayList;

public class ShapeList {

    private ArrayList<Shape> listOfShapes;

    // Constructor to create empty list
    public ShapeList() {
        listOfShapes = new ArrayList<>();
    }

    // Adds a shape to the list
    public void addShape(Shape s) {
        listOfShapes.add(s);
    }

    // Returns shape at position
    public Shape getShape(int pos) {
        if (pos >= 0 && pos < listOfShapes.size()) {
            return listOfShapes.get(pos);
        }
        return null;
    }

    // Removes shape at position
    public Shape removeShape(int pos) {
        if (pos >= 0 && pos < listOfShapes.size()) {
            return listOfShapes.remove(pos);
        }
        return null;
    }

    // Moves all shapes
    public void translateShapes(int dx, int dy) {
        for (Shape s : listOfShapes) {
            s.translate(dx, dy);
        }
    }

    // Scales all shapes
    public void scale(int factor, boolean sign) {
        for (Shape s : listOfShapes) {
            s.scale(factor, sign);
        }
    }

    // Returns area of shape at position
    public double area(int pos) {
        if (pos >= 0 && pos < listOfShapes.size()) {
            return listOfShapes.get(pos).getArea();
        }
        return -1;
    }

    // Returns perimeter of shape at position
    public double perimeter(int pos) {
        if (pos >= 0 && pos < listOfShapes.size()) {
            return listOfShapes.get(pos).getPerimeter();
        }
        return -1;
    }

    // Returns number of shapes in list
    public int getNumberOfShapes() {
        return listOfShapes.size();
    }

    // Displays all shapes
    public String display() {
        String result = "";

        for (Shape s : listOfShapes) {
            result = result + s.display() + "\n";
        }

        return result;
    }
}