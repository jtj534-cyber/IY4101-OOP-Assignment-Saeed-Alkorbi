public class Circle extends Shape {

    private int radius;

    // Constructor to set radius and position
    public Circle(int radius, Coordinates position) {
        super(0, position);
        this.radius = radius;
    }

    // Calculates circle area
    public double getArea() {
        return Math.PI * radius * radius;
    }

    // Calculates circle perimeter
    public double getPerimeter() {
        return 2 * Math.PI * radius;
    }

    // Scales circle size and position
    public void scale(int factor, boolean sign) {
        super.scale(factor, sign);

        if (factor == 0) {
            return;
        }

        if (sign) {
            radius = radius * factor;
        } else {
            radius = radius / factor;
        }
    }

    // Returns circle information
    public String display() {
        return "Circle: radius = " + radius +
                ", position = (" + position.display() + ")" +
                ", area = " + getArea() +
                ", perimeter = " + getPerimeter();
    }
}