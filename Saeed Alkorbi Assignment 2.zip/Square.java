public class Square extends Shape {

    private int side;

    // Constructor to set side and position
    public Square(int side, Coordinates position) {
        super(4, position);
        this.side = side;
    }

    // Calculates square area
    public double getArea() {
        return side * side;
    }

    // Calculates square perimeter
    public double getPerimeter() {
        return 4 * side;
    }

    // Scales square size and position
    public void scale(int factor, boolean sign) {
        super.scale(factor, sign);

        if (factor == 0) {
            return;
        }

        if (sign) {
            side = side * factor;
        } else {
            side = side / factor;
        }
    }

    // Returns square information
    public String display() {
        return "Square: side = " + side +
                ", position = (" + position.display() + ")" +
                ", area = " + getArea() +
                ", perimeter = " + getPerimeter();
    }
}