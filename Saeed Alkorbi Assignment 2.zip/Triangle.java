public class Triangle extends Shape {

    private Coordinates p1;
    private Coordinates p2;
    private Coordinates p3;

    // Constructor to set the three vertices
    public Triangle(Coordinates p1, Coordinates p2, Coordinates p3) {
        super(3, p1);
        this.p1 = p1;
        this.p2 = p2;
        this.p3 = p3;
    }

    // Calculates triangle perimeter
    public double getPerimeter() {
        double a = p1.distance(p2);
        double b = p2.distance(p3);
        double c = p3.distance(p1);
        return a + b + c;
    }

    // Calculates triangle area using Heron's formula
    public double getArea() {
        double a = p1.distance(p2);
        double b = p2.distance(p3);
        double c = p3.distance(p1);
        double s = (a + b + c) / 2.0;
        return Math.sqrt(s * (s - a) * (s - b) * (s - c));
    }

    // Moves all triangle vertices
    public void translate(int dx, int dy) {
        p1.translate(dx, dy);
        p2.translate(dx, dy);
        p3.translate(dx, dy);
        position = p1;
    }

    // Scales all triangle vertices
    public void scale(int factor, boolean sign) {
        if (factor == 0) {
            return;
        }

        p1.scale(factor, sign);
        p2.scale(factor, sign);
        p3.scale(factor, sign);
        position = p1;
    }

    // Returns triangle information
    public String display() {
        return "Triangle: p1 = (" + p1.display() + ")" +
                ", p2 = (" + p2.display() + ")" +
                ", p3 = (" + p3.display() + ")" +
                ", area = " + getArea() +
                ", perimeter = " + getPerimeter();
    }
}