public class Shape {

    protected Coordinates position;
    protected int sides;

    // Constructor to set number of sides and position
    public Shape(int noOfSides, Coordinates coord) {
        this.sides = noOfSides;
        this.position = coord;
    }

    // Returns the position of the shape
    public Coordinates getCoordinates() {
        return position;
    }

    // Returns number of sides
    public int getSides() {
        return sides;
    }

    // Sets new position for the shape
    public void setCoordinates(Coordinates newcoord) {
        this.position = newcoord;
    }

    // Moves the shape using Coordinates class
    public void translate(int dx, int dy) {
        position.translate(dx, dy);
    }

    // Scales the shape position
    public void scale(int factor, boolean sign) {
        position.scale(factor, sign);
    }

    // Default area (will be overridden)
    public double getArea() {
        return 0;
    }

    // Default perimeter (will be overridden)
    public double getPerimeter() {
        return 0;
    }

    // Basic display (will be overridden in subclasses)
    public String display() {
        return "Shape with " + sides + " sides at " + position.display();
    }
}