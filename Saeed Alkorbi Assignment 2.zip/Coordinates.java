public class Coordinates {

    private int x;
    private int y;

    // Constructor to initialize x and y
    public Coordinates(int x, int y) {
        this.x = x;
        this.y = y;
    }

    // Returns x value
    public int getX() {
        return x;
    }

    // Returns y value
    public int getY() {
        return y;
    }

    // Calculates distance between this point and another point
    public double distance(Coordinates p) {
        int dx = p.x - this.x;
        int dy = p.y - this.y;
        return Math.sqrt(dx * dx + dy * dy);
    }

    // Moves the point by dx and dy
    public void translate(int dx, int dy) {
        x = x + dx;
        y = y + dy;
    }

    // Scales the point (multiply or divide)
    public void scale(int factor, boolean sign) {

        // Avoid division by zero
        if (factor == 0) return;

        if (sign) {
            x = x * factor;
            y = y * factor;
        } else {
            x = x / factor;
            y = y / factor;
        }
    }

    // Returns coordinates as text
    public String display() {
        return "X = " + x + ", Y = " + y;
    }
}