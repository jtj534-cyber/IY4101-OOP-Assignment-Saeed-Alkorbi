public class Rectangle extends Shape {

    private int width;
    private int length;

    // Constructor to set width, length and position
    public Rectangle(int width, int length, Coordinates position) {
        super(4, position);
        this.width = width;
        this.length = length;
    }

    // Calculates rectangle area
    public double getArea() {
        return width * length;
    }

    // Calculates rectangle perimeter
    public double getPerimeter() {
        return 2 * width + 2 * length;
    }

    // Scales rectangle size and position
    public void scale(int factor, boolean sign) {
        super.scale(factor, sign);

        if (factor == 0) {
            return;
        }

        if (sign) {
            width = width * factor;
            length = length * factor;
        } else {
            width = width / factor;
            length = length / factor;
        }
    }

    // Returns rectangle information
    public String display() {
        return "Rectangle: width = " + width +
                ", length = " + length +
                ", position = (" + position.display() + ")" +
                ", area = " + getArea() +
                ", perimeter = " + getPerimeter();
    }
}