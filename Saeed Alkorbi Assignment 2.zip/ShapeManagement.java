import java.util.Scanner;

public class ShapeManagement {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        ShapeList list = new ShapeList();
        int choice;

        do {
            System.out.println("1. Add a shape");
            System.out.println("2. Remove a shape by position");
            System.out.println("3. Get information of a shape by position");
            System.out.println("4. Get area and perimeter of a shape by position");
            System.out.println("5. Display all shapes");
            System.out.println("6. Translate all shapes");
            System.out.println("7. Scale all shapes");
            System.out.println("0. Quit");
            System.out.print("Enter your choice: ");

            choice = input.nextInt();

            if (choice == 1) {
                System.out.println("Choose shape type:");
                System.out.println("1. Rectangle");
                System.out.println("2. Square");
                System.out.println("3. Circle");
                System.out.println("4. Triangle");
                System.out.print("Enter shape type: ");

                int type = input.nextInt();

                if (type == 1) {
                    System.out.print("Enter width: ");
                    int width = input.nextInt();
                    System.out.print("Enter length: ");
                    int length = input.nextInt();
                    System.out.print("Enter x position: ");
                    int x = input.nextInt();
                    System.out.print("Enter y position: ");
                    int y = input.nextInt();

                    Rectangle r = new Rectangle(width, length, new Coordinates(x, y));
                    list.addShape(r);
                    System.out.println("Rectangle added.");
                }

                else if (type == 2) {
                    System.out.print("Enter side: ");
                    int side = input.nextInt();
                    System.out.print("Enter x position: ");
                    int x = input.nextInt();
                    System.out.print("Enter y position: ");
                    int y = input.nextInt();

                    Square s = new Square(side, new Coordinates(x, y));
                    list.addShape(s);
                    System.out.println("Square added.");
                }

                else if (type == 3) {
                    System.out.print("Enter radius: ");
                    int radius = input.nextInt();
                    System.out.print("Enter x position: ");
                    int x = input.nextInt();
                    System.out.print("Enter y position: ");
                    int y = input.nextInt();

                    Circle c = new Circle(radius, new Coordinates(x, y));
                    list.addShape(c);
                    System.out.println("Circle added.");
                }

                else if (type == 4) {
                    System.out.print("Enter x1: ");
                    int x1 = input.nextInt();
                    System.out.print("Enter y1: ");
                    int y1 = input.nextInt();

                    System.out.print("Enter x2: ");
                    int x2 = input.nextInt();
                    System.out.print("Enter y2: ");
                    int y2 = input.nextInt();

                    System.out.print("Enter x3: ");
                    int x3 = input.nextInt();
                    System.out.print("Enter y3: ");
                    int y3 = input.nextInt();

                    Triangle t = new Triangle(
                            new Coordinates(x1, y1),
                            new Coordinates(x2, y2),
                            new Coordinates(x3, y3)
                    );
                    list.addShape(t);
                    System.out.println("Triangle added.");
                }

                else {
                    System.out.println("Invalid shape type.");
                }
            }

            else if (choice == 2) {
                System.out.print("Enter position: ");
                int pos = input.nextInt();

                Shape removed = list.removeShape(pos);

                if (removed == null) {
                    System.out.println("Invalid position.");
                } else {
                    System.out.println("Shape removed.");
                }
            }

            else if (choice == 3) {
                System.out.print("Enter position: ");
                int pos = input.nextInt();

                Shape s = list.getShape(pos);

                if (s == null) {
                    System.out.println("Invalid position.");
                } else {
                    System.out.println(s.display());
                }
            }

            else if (choice == 4) {
                System.out.print("Enter position: ");
                int pos = input.nextInt();

                Shape s = list.getShape(pos);

                if (s == null) {
                    System.out.println("Invalid position.");
                } else {
                    System.out.println("Area = " + s.getArea());
                    System.out.println("Perimeter = " + s.getPerimeter());
                }
            }

            else if (choice == 5) {
                System.out.println(list.display());
            }

            else if (choice == 6) {
                System.out.print("Enter dx: ");
                int dx = input.nextInt();
                System.out.print("Enter dy: ");
                int dy = input.nextInt();

                list.translateShapes(dx, dy);
                System.out.println("All shapes translated.");
            }

            else if (choice == 7) {
                System.out.print("Enter factor: ");
                int factor = input.nextInt();
                System.out.print("Enter true to multiply or false to divide: ");
                boolean sign = input.nextBoolean();

                list.scale(factor, sign);
                System.out.println("All shapes scaled.");
            }

            else if (choice == 0) {
                System.out.println("Program ended.");
            }

            else {
                System.out.println("Invalid choice.");
            }

            System.out.println();

        } while (choice != 0);

        input.close();
    }
}